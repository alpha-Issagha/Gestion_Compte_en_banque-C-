#include <iostream>
#include <string>
using namespace std;
#include "head.h"
void cptBanquair::enregistrer()
{
        cout<<endl<<"Enregistrement ....."<<endl;
        cout<<"Numero : ";cin>>client.numCli;
        cout<<"Nom :";cin>>client.nom;
        cout<<"Montant :";cin>>client.montant;
        solde=client.montant;
}
