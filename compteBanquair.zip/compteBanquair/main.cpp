#include <iostream>
#include <string>
#include "head.h"
using namespace std;
int main()
{
    int choix,nb(0);
    cptBanquair compte;
    do
    {
        b:cout<<"1-Enregistrer"<<endl<<"2-Retrait"<<endl<<"3-Depot"<<endl<<"4-afficher"<<endl<<"5-Quiter"<<endl<<"Faites votre choix  : ";cin>>choix;
        switch(choix)
        {
        case 1:
            {
                nb ++;
                compte.enregistrer();
                break;
            }
        case 2:
            {
                if(nb ==0)
                {
                    cout<<endl<<"Veillez enregistrer le compte Avant tout"<<endl;
                    goto b;
                }
            compte.retraite();
            break;
            }
        case 3:
            {
                if(nb ==0)
                {
                    cout<<endl<<"Veillez suivre les etapes par ordre"<<endl;
                    goto b;
                }
                compte.depot();
                break;
            }
        case 4:
            {
                if(nb ==0)
                {
                    cout<<endl<<"Veillez enregistrer le compte Avant tout"<<endl;
                    goto b;
                }
                compte.afficher();
                break;
            }
        case 5:choix=5;break;
        }
    }while(choix != 5);
    return 0;
}
