#include <iostream>
#include <string>
using namespace std;
#include "head.h"
void cptBanquair::depot()
{

    int nbr;
    cout<<"Vous voulez retirer combien ?: ";cin>>nbr;
    j:cout<<endl<<"Voulez allez deposer de l'argent "<<endl<<"1-OUI"<<endl<<"2-NON"<<endl;
    int choix;
    cin>>choix;
    if(choix==1)
    {
        client.montant += nbr;
        cout<<endl<<"Depot effectue "<<endl;
    }
    if(choix != 1&&choix!=2)
        goto j;
        dept = nbr;
}

