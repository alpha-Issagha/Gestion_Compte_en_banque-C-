#include <iostream>
#include <string>
using namespace std;
#include "head.h"
void cptBanquair::retraite()
{
    int nbr;
    cout<<"Vous voulez retirer combien ?: ";cin>>nbr;
    j:cout<<endl<<"Voulez allez retirer de l'argent "<<endl<<"1-OUI"<<endl<<"2-NON"<<endl;
    int choix;
    cin>>choix;
    if(choix==1)
    {
        if(nbr < client.montant)
        client.montant -= nbr;
        else
        {
            cout<<endl<<"le solde de votre compte est insuffisant pour ce retrait"<<endl;
        }
        cout<<endl<<"Retrait effectue "<<endl;
    }
    if(choix != 1&&choix!=2)
        goto j;
        retrait+=nbr;
}
