#ifndef HEAD_H_INCLUDED
#define HEAD_H_INCLUDED
#include <iostream>
#include <string>
using namespace std;
class cptBanquair
{
private:
struct clt
{
    int numCli;
    double montant;
    string nom;
};
clt client;
double dept;
double retrait;
double solde;
public:
    void enregistrer();
    void retraite();
    void depot();
    void afficher();/*
    cptBanquair();
    ~cptBanquair();*/
};
#endif // HEAD_H_INCLUDED
