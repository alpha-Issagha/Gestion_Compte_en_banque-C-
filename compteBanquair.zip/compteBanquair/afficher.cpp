#include <iostream>
#include <string>
using namespace std;
#include "head.h"
void cptBanquair::afficher()
{
    cout<<endl<<'\t'<<"FICHE DU CLIENT"<<endl<<'\t'<<"Numero Client -----------"<<client.numCli<<endl<<'\t'<<"Nom du Client -----------"<<client.nom<<endl<<'\t'<<"Montant -----------------"<<solde<<endl<<'\t'<<"Depot -------------------"<<dept<<endl<<'\t'<<"Retrait -----------------"<<retrait<<endl<<'\t'<<"Solde -------------------"<<client.montant<<endl<<endl;
}
